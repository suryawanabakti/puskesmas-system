import { SVGAttributes } from 'react';

export default function AppLogoIcon(props: SVGAttributes<SVGElement>) {
    return <img src="https://i.pinimg.com/736x/67/a5/3f/67a53fa9615967c9128e85a0144aeafe.jpg" />;
}
